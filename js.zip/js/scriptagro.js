const navHarburger = document.querySelector(".nav_harmbuger ")
const navMenu =  document.querySelector(".menu");

// Toggle Nav

navHarburger.addEventListener("click", () => {
    navMenu.classList.toggle("menu_active");

        //  Burger Show
        navHarburger.classList.toggle('toggle');
});





// Page back to top button
const scrollBtn = document.querySelector('.goup-scroll-btn') ;
window.addEventListener('scroll', () => {
    if(document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
        scrollBtn.style.transform = 'translateX(0px)' ;
    }
    else {
        scrollBtn.style.transform = 'translateX(100px)' ;
    }
})
scrollBtn.addEventListener('click' , () => {
    window.scroll({
        top: 0 ,
        behavior: "smooth"
    })
})
