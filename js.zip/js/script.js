
const navHarburger = document.querySelector(".nav_harmbuger ")
const navMenu =  document.querySelector(".menu");

// Toggle Nav

navHarburger.addEventListener("click", () => {
    navMenu.classList.toggle("menu_active");

        //  Burger Show
        navHarburger.classList.toggle('toggle');
});



// --------------SLider

var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
   var slides = document.getElementsByClassName("client");
   var slideImage = document.getElementsByClassName("partner_1");
   var dots = document.getElementsByClassName("dot");

   for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";
       slideImage[i].style.display = "none";
   }
   for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
}
   slideIndex++;
   if (slideIndex > slides.length) { slideIndex = 1 }
   slides[slideIndex - 1].style.display = "block";
   dots[slideIndex - 1].className += " active";

   slideIndex++;
   if (slideIndex > slideImage.length) { slideIndex = 1 }
   slideImage[slideIndex - 1].style.display = "block";
   dots[slideIndex - 1].className += " active";

   setTimeout(showSlides, 4000); // Change image every 2 seconds
}




// Page back to top button
const scrollBtn = document.querySelector('.scroll-btn') ;
window.addEventListener('scroll', () => {
    if(document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
        scrollBtn.style.transform = 'translateX(0px)' ;
    }
    else {
        scrollBtn.style.transform = 'translateX(100px)' ;
    }
})
scrollBtn.addEventListener('click' , () => {
    window.scroll({
        top: 0 ,
        behavior: "smooth"
    })
})


// -------------------About 
const accordionItemHeaders = document.querySelectorAll(".accordion_item_header");

accordionItemHeaders.forEach(accordionItemHeader => {
  accordionItemHeader.addEventListener("click", event => {
    

    accordionItemHeader.classList.toggle("show");
    const accordionItemBody = accordionItemHeader.nextElementSibling;
    if(accordionItemHeader.classList.contains("show")) {
      accordionItemBody.style.maxHeight = accordionItemBody.scrollHeight + "px";
    }
    else {
      accordionItemBody.style.maxHeight = 0;
    }
    
  });
});

